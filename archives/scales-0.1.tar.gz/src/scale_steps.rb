class ScaleSteps
    TONE = 2
    SEMITONE = 1
end